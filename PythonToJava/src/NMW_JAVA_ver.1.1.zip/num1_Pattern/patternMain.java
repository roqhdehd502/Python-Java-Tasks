package num1_Pattern;

public class patternMain {
	public static void main(String[] args) {
		System.out.println("FFFFFFF  U     U  NN    NN");
		System.out.println("FF       U     U  NNN   NN");
		System.out.println("FFFFFFF  U     U  NN N  NN");
		System.out.println("FF        U   U   NN  N NN");
		System.out.println("FF         UUU    NN   NNN");
	}
}